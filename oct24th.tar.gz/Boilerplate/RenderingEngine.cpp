/*
 * RenderingEngine.cpp
 *
 *  Created on: Sep 10, 2018
 *      Author: John Hall
 */

#include "RenderingEngine.h"

#include <iostream>
#include <ctime>		// for tiem use

//cpp file purposely included here because it just contains some global functions
#include "ShaderTools.h"

RenderingEngine::RenderingEngine() {
	quadraticProgram = ShaderTools::InitializeShaders("shaders/tessControl.glsl", "shaders/tessEval.glsl", 0);
	cubicProgram = ShaderTools::InitializeShaders("shaders/cubic1.glsl", "shaders/cubic2.glsl", 0);
	lineProgram = ShaderTools::InitializeShaders("shaders/line1.glsl", "shaders/line2.glsl", 0);
	pointProgram = ShaderTools::InitializeShaders("shaders/tessControl.glsl", "shaders/tessEval.glsl", 1);

	if (quadraticProgram == 0) {
		std::cout << "Program could not initialize shaders, TERMINATING" << std::endl;
		return;
	}
	time = 0.0f;
}

RenderingEngine::~RenderingEngine() {

}

void RenderingEngine::RenderScene(const std::vector<Geometry>& objects) {
	//Clears the screen to a dark grey background
	glClearColor(0.2f, 0.2f, 0.2f, 1.0f);
	glClear(GL_COLOR_BUFFER_BIT);

	time += 0.01f;
	// animation 60fps tiem += 0.01f, 24fps time += 0.24f?  bad
	// how much time past since last scene, frame independent
	// fmod for disp and show up on the othe end
	// do it here
	// dont use time

	// time_t start, finish;

	// 0:  tea pot scene
	// 1:  fish scene
	// 2:  draw polygon and point
	// 3:  point
	float textlength = 2.0f;

	time_t current = clock();
	glm::mat4 translation = glm::translate(glm::mat4(1.0f), glm::vec3(-fmod((float) current, 10) + textlength, -0.5f, 0));
		printf("\n");
		printf("\n");
		//printf("time: %f", time);
	for (int i = 0; i < 4; i++) {
		for (int j = 0; j < 4; j++) {
			printf("[%f] ", translation[i][j]);
		}
		printf("\n");
	}

	GLuint MatrixID;
	for (const Geometry& g : objects) {
		if (g.getState() == 0) {			// part 1.1
			glUseProgram(quadraticProgram);
			glPatchParameteri(GL_PATCH_VERTICES, 3);
			MatrixID = glGetUniformLocation(quadraticProgram, "transformation");
		} 
		else if (g.getState() == 1) {		// part 1.2
			glUseProgram(cubicProgram);
			glPatchParameteri(GL_PATCH_VERTICES, 4);
			MatrixID = glGetUniformLocation(cubicProgram, "transformation");
		}
		else if (g.getState() == 2) {		// line
			glUseProgram(lineProgram);
			glPatchParameteri(GL_PATCH_VERTICES, 2);
			MatrixID = glGetUniformLocation(lineProgram, "transformation");
		}
		else if (g.getState() == 3) {		// point
			glUseProgram(pointProgram);
			glPointSize(10);
		}
		glUniformMatrix4fv(MatrixID, 1, GL_FALSE, &translation[0][0]);


		glBindVertexArray(g.vao);
		glDrawArrays(g.drawMode, 0, g.verts.size());
		// reset state to default (no shader or geometry bound)
		glBindVertexArray(0);
	}
	glUseProgram(0);
	// check for an report any OpenGL errors
	CheckGLErrors();
}

void RenderingEngine::assignBuffers(Geometry& geometry) {
	//Generate vao for the object
	//Constant 1 means 1 vao is being generated
	glGenVertexArrays(1, &geometry.vao);
	glBindVertexArray(geometry.vao);

	//Generate vbos for the object
	//Constant 1 means 1 vbo is being generated
	glGenBuffers(1, &geometry.vertexBuffer);
	glBindBuffer(GL_ARRAY_BUFFER, geometry.vertexBuffer);
	//Parameters in order: Index of vbo in the vao, number of primitives per element, primitive type, etc.
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, (void*)0);
	glEnableVertexAttribArray(0);

	/*glGenBuffers(1, &geometry.normalBuffer);
	glBindBuffer(GL_ARRAY_BUFFER, geometry.normalBuffer);
	glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, 0, (void*)0);
	glEnableVertexAttribArray(2);*/

	glGenBuffers(1, &geometry.colorBuffer);
	glBindBuffer(GL_ARRAY_BUFFER, geometry.colorBuffer);
	//Parameters in order: Index of vbo in the vao, number of primitives per element, primitive type, etc.
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 0, (void*)0);
	glEnableVertexAttribArray(1);

	/*glGenBuffers(1, &geometry.uvBuffer);
	glBindBuffer(GL_ARRAY_BUFFER, geometry.uvBuffer);
	glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 0, (void*)0);
	glEnableVertexAttribArray(1);*/


}

void RenderingEngine::setBufferData(Geometry& geometry) {
	//Send geometry to the GPU
	//Must be called whenever anything is updated about the object
	glBindBuffer(GL_ARRAY_BUFFER, geometry.vertexBuffer);
	glBufferData(GL_ARRAY_BUFFER, sizeof(glm::vec3) * geometry.verts.size(), geometry.verts.data(), GL_STATIC_DRAW);

	/*glBindBuffer(GL_ARRAY_BUFFER, geometry.normalBuffer);
	glBufferData(GL_ARRAY_BUFFER, sizeof(glm::vec3) * geometry.normals.size(), geometry.normals.data(), GL_STATIC_DRAW);*/

	glBindBuffer(GL_ARRAY_BUFFER, geometry.colorBuffer);
	glBufferData(GL_ARRAY_BUFFER, sizeof(glm::vec3) * geometry.colors.size(), geometry.colors.data(), GL_STATIC_DRAW);

	//glBindBuffer(GL_ARRAY_BUFFER, geometry.uvBuffer);
	//glBufferData(GL_ARRAY_BUFFER, sizeof(glm::vec2) * geometry.uvs.size(), geometry.uvs.data(), GL_STATIC_DRAW);
}

void RenderingEngine::deleteBufferData(Geometry& geometry) {
	glDeleteBuffers(1, &geometry.vertexBuffer);
	glDeleteBuffers(1, &geometry.normalBuffer);
	glDeleteBuffers(1, &geometry.colorBuffer);
	glDeleteBuffers(1, &geometry.uvBuffer);
	glDeleteVertexArrays(1, &geometry.vao);
}

bool RenderingEngine::CheckGLErrors() {
	bool error = false;
	for (GLenum flag = glGetError(); flag != GL_NO_ERROR; flag = glGetError())
	{
		std::cout << "OpenGL ERROR:  ";
		switch (flag) {
		case GL_INVALID_ENUM:
			std::cout << "GL_INVALID_ENUM" << std::endl; break;
		case GL_INVALID_VALUE:
			std::cout << "GL_INVALID_VALUE" << std::endl; break;
		case GL_INVALID_OPERATION:
			std::cout << "GL_INVALID_OPERATION" << std::endl; break;
		case GL_INVALID_FRAMEBUFFER_OPERATION:
			std::cout << "GL_INVALID_FRAMEBUFFER_OPERATION" << std::endl; break;
		case GL_OUT_OF_MEMORY:
			std::cout << "GL_OUT_OF_MEMORY" << std::endl; break;
		default:
			std::cout << "[unknown error code]" << std::endl;
		}
		error = true;
	}
	return error;
}
